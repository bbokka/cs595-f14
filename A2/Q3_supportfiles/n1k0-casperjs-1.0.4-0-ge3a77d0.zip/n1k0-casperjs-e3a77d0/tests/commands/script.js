var casper = require('casper').create();
casper.echo('it works');
casper.exit();
